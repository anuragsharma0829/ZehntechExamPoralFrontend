import re
#input from usre...
pwd=input("Enter Password\n")
 
if pwd == "\n" or pwd == " ":
    print("Password cannot be a newline or space")

elif 9 >= len(pwd) >= 20:
    print("Password length must be 9 to 20 characters")

elif re.search(r'(.)\1\1', pwd):
    print("Weak Password Same character repeats three or more times in a row")

elif re.search(r'(..)(.*?)\1', pwd):
    print("Weak password Same string pattern repetition")

else:
    print("Strong Password")
