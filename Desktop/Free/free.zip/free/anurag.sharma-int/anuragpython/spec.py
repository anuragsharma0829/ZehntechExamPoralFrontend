#intilizing the string...
gvn_string="123abcjw:, .@! eiw"
#print the String...
print("initial string : ",gvn_string)
#special symbol in given string..
special=(":,.@!")
for i in special:
 gvn_string=gvn_string.replace(i,"")
 #print final string...
print("final string : ",gvn_string,)
