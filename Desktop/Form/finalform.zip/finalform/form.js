function seterror(id, error) {
    element = document.getElementById(id);
    element.getElementsByClassName('formerror')[0].innerHTML = error;

}
function Errorcleaner() {
    errors = document.getElementsByClassName("formerror");
    for (let item of errors) {
        item.innerHTML = "";
    }
}

function validateForm() {
    let returnval = true;
    Errorcleaner()
    // first name
    let name = document.forms['myForm']["fname"].value;
    let numreg = /^[A-Za-z]+$/;
    if (!(name.match(numreg))) {
        seterror("name", "*Numbers not allowed in first name ");
        returnval = false;
    }
     if (name.length < 3) {
        seterror("name", "*Length of name is too short");
        returnval = false;
    }
   if (name.length == 0) {
        seterror("name", "*Length should not be zero ");
        returnval = false;
    }

    // last name 
    let name1 = document.forms['myForm']["flname"].value;
    if (!(name1.match(numreg))) {
        seterror("name1", "*Numbers not allowed");
        returnval = false;
    }

    if (name1.length < 3) {
        seterror("name1", "*Length of name is too short");
        returnval = false;
    }
    if (name1.length == 0) {
        seterror("name1", "*Name should not be zero");
        returnval = false;
    }

    // email 
    let email = document.forms['myForm']["femail"].value;

    if (email.length > 30) {
        seterror("email", "*email is too long");
        returnval = false;
    }
    if (email.length == 0) {
        seterror("email", "*email should not be zero");
        returnval = false;
    }

    // password

    let password = document.forms['myForm']["fpass"].value;
   

    if (password.length < 6) {
        seterror("password", "*password should be more than 6");
        returnval = false;
    }
    if (password.length == 0) {
        seterror("password", "*password should not be zero");
        returnval = false;
    }
  


    
    // match password and confirmpassward
    let cpassword = document.forms['myForm']["fcpass"].value;
    if (cpassword != password) {
        seterror("cpassword", "*password not match ");
        returnval = false;
    }
    
    return returnval;

}
function terms_changed(termsCheckBox){
    //If the checkbox has been checked
    if(termsCheckBox.checked){
        //Set the disabled property to FALSE and enable the button.
        document.getElementById("submit_button").disabled = false;
    } else{
        //Otherwise, disable the submit button.
        document.getElementById("submit_button").disabled = true;
    }
}